# projet-django

nom et prenom binome : RAHEL Othmane & HOULAIL Yassine
//
lien overleaf :https://www.overleaf.com/project/682f36027bfbb262c0c8737a
